import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Brain, BookOpen, Video, ImageIcon } from "lucide-react";

export default function HeladoNeuro() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-100 to-purple-100 p-6 text-gray-800">
      <header className="text-center py-8">
        <h1 className="text-5xl font-bold text-purple-700">HeladoNeuro 🍦🧠</h1>
        <p className="mt-2 text-lg max-w-2xl mx-auto">
          Concientizando sobre el cerebro y el comportamiento a través de la ciencia, imágenes y videos.
        </p>
      </header>

      <main className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        <Card className="bg-white shadow-xl rounded-2xl">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4 mb-4">
              <BookOpen className="w-6 h-6 text-indigo-500" />
              <h2 className="text-xl font-semibold">Investigaciones</h2>
            </div>
            <p className="text-sm text-gray-600">
              Accede a artículos científicos y estudios actualizados que exploran el funcionamiento del cerebro humano.
            </p>
            <Button className="mt-4 w-full">Ver investigaciones</Button>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-xl rounded-2xl">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4 mb-4">
              <ImageIcon className="w-6 h-6 text-pink-500" />
              <h2 className="text-xl font-semibold">Infografías</h2>
            </div>
            <p className="text-sm text-gray-600">
              Visualiza conceptos complejos de forma simple a través de recursos gráficos educativos.
            </p>
            <Button className="mt-4 w-full">Ver infografías</Button>
          </CardContent>
        </Card>

        <Card className="bg-white shadow-xl rounded-2xl">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4 mb-4">
              <Video className="w-6 h-6 text-red-500" />
              <h2 className="text-xl font-semibold">Videos</h2>
            </div>
            <p className="text-sm text-gray-600">
              Disfruta de contenido en formato horizontal que explica procesos neurocientíficos de manera clara y atractiva.
            </p>
            <Button className="mt-4 w-full">Ver videos</Button>
          </CardContent>
        </Card>
      </main>

      <footer className="mt-12 text-center text-sm text-gray-500">
        © 2025 HeladoNeuro. Hecho con 🍦 y 🧠 para despertar tu curiosidad.
      </footer>
    </div>
  );
}
